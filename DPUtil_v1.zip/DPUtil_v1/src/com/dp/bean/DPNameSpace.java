package com.dp.bean;

public class DPNameSpace {
	
//	2.2	Multi Protocol Gateway Name
	public String mpgwName;
//	2.3	Web Service Proxy Name
	public String wspName;
//	2.4	Front Side Protocol Name
	public String fsh;
	public String sslFsh;
	//	2.5	SSL Proxy
	public String sslProxy;
//	2.5.1	Forward Crypto Profile
		public String forwardCryptoPro;
//		2.5.2	Reverse Crypto Profile
		public String reverseCryptoPro;
//		2.5.3	Identification Credentials
		public String identificationCred;
//			2.5.3.1	Crypto Key
			public String cryptoKey;
//			2.5.3.2	Identification Certificate
			public String identificationCert;
//		2.5.4	Validation Credentials
		public String validationCred; 
//			2.5.4.1	Validation Certificate
			public String validationCert;
//	2.6	SSL Client Crypto Profile
		public String clientCryptoPro;
//	2.7	Multi-Protocol Gateway Policy
		public String policy;
//	2.8 Actions
//		2.8.1 Match
		public String matchAction;
//		2.8.2	AAA Policy
		public String aaaPolicy;
//		2.8.2.1	LDAP Search Parameters
		public String LDAP_PARAMS;
		
//**************************All Getter and Setters*****************************

		public String getMpgwName() {
			return mpgwName;
		}
		public void setMpgwName(String mpgwName) {
			this.mpgwName = mpgwName;
		}
		public String getWspName() {
			return wspName;
		}
		public void setWspName(String wspName) {
			this.wspName = wspName;
		}
		public String getFsh() {
			return fsh;
		}
		public void setFsh(String fsh) {
			this.fsh = fsh;
		}
		public String getSslProxy() {
			return sslProxy;
		}
		public void setSslProxy(String sslProxy) {
			this.sslProxy = sslProxy;
		}
		public String getForwardCryptoPro() {
			return forwardCryptoPro;
		}
		public void setForwardCryptoPro(String forwardCryptoPro) {
			this.forwardCryptoPro = forwardCryptoPro;
		}
		public String getReverseCryptoPro() {
			return reverseCryptoPro;
		}
		public void setReverseCryptoPro(String reverseCryptoPro) {
			this.reverseCryptoPro = reverseCryptoPro;
		}
		public String getIdentificationCred() {
			return identificationCred;
		}
		public void setIdentificationCred(String identificationCred) {
			this.identificationCred = identificationCred;
		}
		public String getCryptoKey() {
			return cryptoKey;
		}
		public void setCryptoKey(String cryptoKey) {
			this.cryptoKey = cryptoKey;
		}
		public String getIdentificationCert() {
			return identificationCert;
		}
		public void setIdentificationCert(String identificationCert) {
			this.identificationCert = identificationCert;
		}
		public String getValidationCred() {
			return validationCred;
		}
		public void setValidationCred(String validationCred) {
			this.validationCred = validationCred;
		}
		public String getValidationCert() {
			return validationCert;
		}
		public void setValidationCert(String validationCert) {
			this.validationCert = validationCert;
		}
		public String getClientCryptoPro() {
			return clientCryptoPro;
		}
		public void setClientCryptoPro(String clientCryptoPro) {
			this.clientCryptoPro = clientCryptoPro;
		}
		public String getPolicy() {
			return policy;
		}
		public void setPolicy(String policy) {
			this.policy = policy;
		}
		public String getMatchAction() {
			return matchAction;
		}
		public void setMatchAction(String matchAction) {
			this.matchAction = matchAction;
		}
		public String getAaaPolicy() {
			return aaaPolicy;
		}
		public void setAaaPolicy(String aaaPolicy) {
			this.aaaPolicy = aaaPolicy;
		}
		public String getLDAP_PARAMS() {
			return LDAP_PARAMS;
		}
		public void setLDAP_PARAMS(String lDAP_PARAMS) {
			LDAP_PARAMS = lDAP_PARAMS;
		}
		public String getSslFsh() {
			return sslFsh;
		}
		public void setSslFsh(String sslFsh) {
			this.sslFsh = sslFsh;
		}
}
