package com.dp.controller;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import com.dp.bean.DPNameSpace;

public class FileController {
//	private static final 
	

	
	public static DPNameSpace nameSpacing(String projectName) {
		// TODO Auto-generated constructor stub
		DPNameSpace nameSpace = null;		
		nameSpace = new DPNameSpace();
		nameSpace.setMpgwName(projectName+"_MPGW");
		nameSpace.setWspName(projectName+"_WSP");
		nameSpace.setFsh(projectName+"_FSH");
		nameSpace.setSslFsh(projectName+"_FSH_SSL");
		nameSpace.setSslProxy(projectName+"_SSL");
		nameSpace.setSslProxy(projectName+"_SSL_PROXY_PROFILE");
		nameSpace.setForwardCryptoPro(projectName+"_FORWARD_CRYPTO_PROFILE");
		nameSpace.setReverseCryptoPro(projectName+"_REVERSE_CRYPTO_PROFILE");
		nameSpace.setIdentificationCert(projectName+"_IDENTIFICATION_CREDENTIALS");
		nameSpace.setCryptoKey(projectName+"_CRYPTO_KEY");
		nameSpace.setIdentificationCert(projectName+"_IDENTIFICATION_ CERT");
		nameSpace.setValidationCred(projectName+"_VALIDATION_CREDENTIALS");
		nameSpace.setValidationCert(projectName+"_VALIDATION_ CERT");
		nameSpace.setClientCryptoPro(projectName+"_SSL_CLIENT_PROFILE");
		nameSpace.setPolicy(projectName+"_POLICY");
		nameSpace.setMatchAction(projectName+"_MATCH_ACTION");
		nameSpace.setAaaPolicy(projectName+"_AAA_POLICY");
		nameSpace.setLDAP_PARAMS(projectName+"LDAP_PARAMS");
		return nameSpace;
	}
	
	public static File fileWriter(DPNameSpace nameSpaceObj) throws IOException
	{
		File file = new File("C:/Jan Workspace/DPUtil_v1/text.txt");
		PrintWriter write = new PrintWriter(file);
		write.print(" ");
		write.close();
		FileWriter fr = new FileWriter(file, true);
		fr.write("Service Names      : "+nameSpaceObj.getMpgwName()+"\n");
		fr.write("                   : "+nameSpaceObj.getWspName()+"\n");
		fr.write("*********************************************************************");
		fr.write("Front Side Handler : "+nameSpaceObj.getFsh()+"\n");
		fr.write("                     "+nameSpaceObj.getSslFsh()+"\n");
		fr.write("*********************************************************************");
		fr.write("SSL PROXY PROFILE  : "+nameSpaceObj.getSslProxy()+"\n"+"\n");
		fr.write("                         REVERSE CRYPTO PROFILE:	 "+nameSpaceObj.getReverseCryptoPro()+"\n");
		fr.write("                                                    Identification Credential: "+nameSpaceObj.getIdentificationCred()+"\n");
		fr.write("                                                                               "+nameSpaceObj.getClientCryptoPro()+"\n");
		fr.write("                                                                               "+nameSpaceObj.getIdentificationCert()+"\n");
		fr.write("                         FORWARD CRYPTO PROFILE:	 "+nameSpaceObj.getForwardCryptoPro()+"\n");
		fr.write("                                                        Validation Credential: "+nameSpaceObj.getValidationCred()+"\n");
		fr.write("                                                                               "+nameSpaceObj.getValidationCert()+"\n");
	
		fr.flush();
		fr.close();
		return file;
		
		
		}

}
