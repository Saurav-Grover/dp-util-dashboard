package com.dp.servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DownloadServlet
 */
//@WebServlet(description = "Download Servlet", urlPatterns = {"/download"})
public class DownloadServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/plain");
		response.setHeader("Content-disposition","attachment; filename=text.txt");
		File file = new File("C:/Jan Workspace/DPUtil_v1/text.txt");
		 OutputStream out = response.getOutputStream();
         FileInputStream in = new FileInputStream(file);
         byte[] buffer = new byte[1024];
         int length;
         while ((length = in.read(buffer)) > 0){
            out.write(buffer, 0, length);
         }
         in.close();
         out.flush();
	}


}
