package com.dp.servlet;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dp.bean.DPNameSpace;
import com.dp.controller.FileController;

/**
 * Servlet implementation class FileGenerator
 */
@WebServlet(description = "This servlet will generate the File consist of all object names")
public class FileGenerator extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
//		System.out.println("In case if ");
		String projectName = request.getParameter("projectName");
		fileGenrator(projectName);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/download");
		dispatcher.forward(request, response);
	}
	
	public File fileGenrator(String projectName) throws IOException
	{
		DPNameSpace nameSpace = FileController.nameSpacing(projectName);
		File file = FileController.fileWriter(nameSpace);
		return file;
	}

}
